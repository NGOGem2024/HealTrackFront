import React from 'react'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialIcons } from '@expo/vector-icons';

import Home from './HomeScreen';
import LoginScreen from '../LoginScreen';
import Doctor from './DoctorScreen';
import Patient from './PatientScreen'
import Therapy from './TherapyHistory';
import setting from './setting';
import PatientRegister from '../PatientRegister';
import HomeStackNavigator from '../HomeStackNavigator';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../types/types';
import TherapyScreen from './TherapyHistory';

type TabScreenProps = {
  navigation: StackNavigationProp<RootStackParamList, 'Tabs'>;
};

const Tab = createBottomTabNavigator();
const TabScreen: React.FC = () => {

  return (
    <Tab.Navigator initialRouteName='Login' screenOptions={{
      tabBarActiveTintColor: '#24A0ED',
      tabBarInactiveTintColor: 'black',
      tabBarActiveBackgroundColor: 'white',
      tabBarInactiveBackgroundColor: '#24A0ED',
      tabBarLabelStyle: {
        fontSize: 15,
      },

    }}>


      <Tab.Screen name='Home'
        component={HomeStackNavigator}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name='home' size={size} color={color} />
          ),
          headerShown: false
        }}
      />
      <Tab.Screen name='Doctor'
        component={Doctor}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name='person' size={size} color={color} />
          ),
        }}

      />
      <Tab.Screen name='Patient'
        component={PatientRegister}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name='people' size={size} color={color} />
          ),

        }}


      />
      <Tab.Screen name='Therapy'
        component={TherapyScreen}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name='healing' size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen name='setting'
        component={setting}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name='settings' size={size} color={color} />
          ),
        }}

      />
    </Tab.Navigator>
  )
}

export default TabScreen