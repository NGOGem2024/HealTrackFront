import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../types/types';

type PaitentScreenProps = {
  navigation: StackNavigationProp<RootStackParamList, 'Patient'>;
};


const PatientScreen = () => {
  return (
    <View>
      <Text>PatientScreen</Text>
    </View>
  )
}

export default PatientScreen

const styles = StyleSheet.create({})