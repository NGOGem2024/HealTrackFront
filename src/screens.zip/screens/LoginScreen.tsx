import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../types/types'; // Adjust the path as necessary
import { AntDesign, MaterialCommunityIcons, Octicons } from '@expo/vector-icons';
//import { colors } from '@mui/material';
import { GestureHandlerRootView, TouchableOpacity } from 'react-native-gesture-handler';

type LoginScreenProps = {
  navigation: StackNavigationProp<RootStackParamList, 'Login'>;
};

const LoginScreen: React.FC<LoginScreenProps> = ({ navigation }) => {

  const [fdata, setfdata] = useState({ email: '', password: '' });
  const [emailfocus, setEmailfocus] = useState(false);
  const [passwordfocus, setPasswordfocus] = useState(false);
  const [showpassword, setShowpassword] = useState(false);
  // const [password, setPassword] = useState('');
  const [errormsg, setErrormsg] = useState(String || null);

  const handleLogin = () => {
    if (fdata.email == '' || fdata.password == '') {
      setErrormsg('⚠ All fields are required');
      return;
    }
    else {
      fetch('http://192.168.191.237:8000/signin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(fdata)
      })
        .then(res => res.json())
        .then(data => {
          console.log(data);
          if (data.error) {
            setErrormsg(data.err);
          } else {
            alert('Login Successfully');
            navigation.navigate('Home');
          }
        })
        .catch(error => {
          console.error('Error:', error);
        });
    }
  };

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <View style={styles.container}>
        <Text style={styles.title}>Sign In</Text>
        {/* <Text style={styles.quote}>Welcome back you've been missed!</Text> */}
        <View style={styles.inputout}>
          <AntDesign name="user" size={24} color={emailfocus === true ? 'black' : 'grey'} />
          <TextInput
            style={styles.input}
            placeholder="Email"
            cursorColor={'#262626'}

            value={fdata.email}
            onChangeText={text => setfdata({ ...fdata, email: text })}
            onFocus={() => {
              setEmailfocus(true);
              setPasswordfocus(false);
            }}
          />
        </View>
        <View style={styles.inputout}>
          <MaterialCommunityIcons name="lock-outline" size={24}
            color={passwordfocus === true ? 'black' : 'grey'} />
          <TextInput
            style={styles.input}
            cursorColor={'#262626'}
            placeholder="Password"
            value={fdata.password}
            onChangeText={text => setfdata({ ...fdata, password: text })}

            onFocus={() => {
              setEmailfocus(false);
              setPasswordfocus(true);
              setShowpassword(false);
            }}
            secureTextEntry={showpassword === false ? true : false}
          />
          <Text
            style={styles.icon}>
            <Octicons name={showpassword === false ? 'eye-closed' : 'eye'} size={24} color="black"
              onPress={() => setShowpassword(!showpassword)} />
          </Text>
        </View>

        <View style={styles.btn1}>
          <Button color="black" title="Login" onPress={handleLogin} />
        </View>
        <View style={styles.btn2}>
          <Button color="black" title="Register" onPress={() => navigation.navigate('Register')} />
        </View>

        <Text style={styles.text}>Forgot your Password?</Text>
        <Text style={styles.or}>OR</Text>
        <Text style={styles.txt}>Sign In With</Text>

        <View style={styles.gf}>
          <TouchableOpacity>
            <View style={styles.gficon}><AntDesign name="google" size={24} color="black" /></View>
          </TouchableOpacity>
          <TouchableOpacity>
            <View style={styles.gficon}><AntDesign name="facebook-square" size={24} color="black" /></View>
          </TouchableOpacity>
        </View>
      </View>
    </GestureHandlerRootView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    height: "50%",
    width: "100%",
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 50,
    marginTop: '10%',
    marginVertical: 50,
  },
  title: {
    //marginVertical:100,
    justifyContent: 'center',
    fontSize: 50,
    marginBottom: 20,
    color: 'black',
  },
  inputout: {
    flexDirection: 'row',
    marginVertical: 10,
    width: '100%',
    backgroundColor: 'white',
    paddingHorizontal: 10,
    paddingVertical: 10,
    elevation: 20,
    borderRadius: 10
  },
  btn1: {
    height: 60,
    width: '100%',
    marginTop: 20,


  },
  btn2: {
    height: 60,
    width: '100%',
    marginVertical: -10

  },
  quote: {
    color: "black",
    marginBottom: 25,
    fontSize: 25,
    textAlign: "center",
  },
  text: {
    color: "black",
    marginBottom: 5,
    marginTop: 10,
  },
  input: {
    fontSize: 18,
    marginLeft: 10,
    width: '100%'
  },
  icon: {
    position: 'absolute',
    right: 10,
    top: 15,
  },
  or: {
    color: "black",
    fontWeight: 'bold'
  },
  txt: {
    fontSize: 20,
    color: "black"
  },
  gf: {
    flexDirection: "row"
  },
  gficon: {

    width: 50,
    margin: -5,
    borderRadius: 10,
    padding: 10,
    marginTop: 10,
    alignItems: 'center',
  },

  errormessage: {
    color: 'black',
    fontSize: 18,
    textAlign: 'center',
    backgroundColor: '#F50057',
    padding: 5,
    borderRadius: 10,
    marginTop: -15,
    margin: 5
  }
});

export default LoginScreen;