import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { NavigationContainer } from '@react-navigation/native'
import DoctorScreen from './BottomTab/DoctorScreen'
import PatientScreen from './BottomTab/PatientScreen'
import TherapyScreen from './BottomTab/TherapyHistory'
import HomeScreen from './HomeScreen'
import LoginScreen from './LoginScreen'
import PatientRegister from './PatientRegister'
import UpdatePatient from './UpdatePatient'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { StackNavigationProp } from '@react-navigation/stack'
import { RootStackParamList } from '../types/types'
import TabScreen from './BottomTab/TabScreen'

type HomeStackNavigatorProps = {
    navigation: StackNavigationProp<RootStackParamList, 'Home'>;
};
const Stack = createNativeStackNavigator();



const HomeStackNavigator = () => {
    return (

        <Stack.Navigator initialRouteName='Home'>

            {/*<Stack.Screen name="Register" component={RegisterScreen} />*/}
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="UpdatePatient" component={UpdatePatient} />
            <Stack.Screen name="Doctor" component={DoctorScreen} />
            <Stack.Screen name="Home" component={HomeScreen} />
            <Stack.Screen name="Patient" component={PatientScreen} />
            <Stack.Screen name="Therapy" component={TherapyScreen} />
            <Stack.Screen name="PatientRegister" component={PatientRegister} />
            <Stack.Screen name="Tabs" component={TabScreen} />


        </Stack.Navigator>



    )
}

export default HomeStackNavigator

const styles = StyleSheet.create({})