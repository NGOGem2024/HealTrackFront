import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { RootStackParamList } from "../types/types";
import UpdatePatient from "./UpdatePatient";
import { GestureHandlerRootView, ScrollView } from "react-native-gesture-handler";

type PaitentRegisterScreenProps = {
  navigation: StackNavigationProp<RootStackParamList, "PaitentRegister">;
};

const PaitentRegister: React.FC<PaitentRegisterScreenProps> = ({ navigation }) => {
  const [patientName, setPatientName] = useState("");
  const [email, setEmail] = useState("");
  const [ContactNo, setContact] = useState("");

  const handlePaitentRegister = () => {
    if (patientName.trim() === "") {
      Alert.alert("Error", "Please fill in all fields");
      return;
    }
    // Perform logic to add patient
    // For example, you can make an API call here to add the patient
    // After adding the patient, you can navigate to another screen or perform any necessary actions
    Alert.alert("Success", "Paitent Registered successfully");
    navigation.navigate('UpdatePatient');
  };


  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: "#2a7fba" }}>
      <ScrollView>
        <View style={styles.container}>
          <Text style={styles.title}> Register  patient</Text>
          <View style={styles.inputout}>
            <Text style={[styles.label, styles.nameLabel]}>Patient Name:</Text>
            <TextInput
              style={styles.input}
              value={patientName}
              onChangeText={setPatientName}
              
            />
          </View>
          <View style={styles.inputout}>
        
            <Text style={[styles.label, styles.nameLabel]}>Email:</Text>

            <TextInput
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              
            />
          </View>
          <View style={styles.inputout}>
            <Text style={[styles.label, styles.nameLabel]}>ContactNo:</Text>

            <TextInput
              style={styles.input}
              value={ContactNo}
              onChangeText={setContact}
              keyboardType="numeric"

            />
          </View>

          <View style={styles.btn}>
            <Button
              color="#264d73"
              title="Save"
              onPress={handlePaitentRegister}
            />
          </View>
        </View>
      </ScrollView>
    </GestureHandlerRootView>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#2a7fba",
    paddingHorizontal: 30,
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  formContainer: {
    width: "80%",
  },
  title: {
    fontSize: 30,
    marginBottom: 20,
    color: "white",
    textAlign: "center",
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  label: {
    width: "30%",
    marginRight: 10,
    color: "white",
    fontSize:30,
  },
  nameLabel: {
    fontSize: 15,
    color:"black" // Custom font size for Patient Name label
  },

  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ccc",
    paddingVertical: 8,
    paddingHorizontal: 10,
    backgroundColor: "white",
    borderRadius: 5,
    color: "#333",
  },
  inputout:{
    marginBottom:20,
  },
  btn: {
    marginTop: 20,
    width: "50%",
  },
});


export default PaitentRegister;
