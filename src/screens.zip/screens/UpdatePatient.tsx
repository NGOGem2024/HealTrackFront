import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Button,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from "react-native";
import { StackNavigationProp } from "@react-navigation/stack";
import { RootStackParamList } from "../types/types";
import { GestureHandlerRootView, ScrollView } from "react-native-gesture-handler";
import { Calendar } from "react-native-calendars";

type UpdatePatientProps = {
  navigation: StackNavigationProp<RootStackParamList, "UpdatePatient">;
};

const UpdatePatient: React.FC<UpdatePatientProps> = ({ navigation }) => {
  const [patientName, setPatientName] = useState("");
  const [email, setEmail] = useState("");
  const [ContactNo, setContact] = useState("");
  const [gender, setGender] = useState("");
  const [BloodGroup, setBloodGroup] = useState("");
  const [age, setAge] = useState("");
  const [Address1, setAddress1] = useState("");
  const [Address2, setAddress2] = useState("");
  const [SymptomId, setSymptomId] = useState("");

  const handleUpdatePatient = () => {
    if (patientName.trim() === "" || age.trim() === "" || gender.trim() === "") {
      Alert.alert("Error", "Please fill in all fields");
      return;
    }
    // Perform logic to add patient
    // For example, you can make an API call here to add the patient
    // After adding the patient, you can navigate to another screen or perform any necessary actions
    Alert.alert("Success", "Patient Update successfully");
  };
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <ScrollView>
        <View style={styles.container}>
          <Text style={styles.title}>Update Patient</Text>
          <View style={styles.inputContainer}>
            <Text style={[styles.label, styles.nameLabel]}>patientName:</Text>
            <TextInput
              style={styles.input}
              value={patientName}
              onChangeText={setPatientName}
            />
          </View>
          <View style={styles.inputContainer}>
            <Text style={[styles.label, styles.nameLabel]}>Email:</Text>
            <TextInput
              style={styles.input}
              value={email}
              onChangeText={setEmail}
            />
          </View>
          <View style={styles.inputContainer}>
            <Text style={[styles.label, styles.nameLabel]}>ContactNo:</Text>
            <TextInput
              style={styles.input}
              value={ContactNo}
              onChangeText={setContact}
              keyboardType="numeric"

            />
          </View>
          <View style={styles.inputContainer}>
            <Text style={[styles.label, styles.nameLabel]}>Gender:</Text>
            <TextInput
              style={styles.input}
              value={gender}
              onChangeText={setGender}
            />
          </View>
          <View style={styles.inputContainer}>

            <Text style={[styles.label, styles.nameLabel]}>BloodGroup:</Text>
            <TextInput
              style={styles.input}
              value={BloodGroup}
              onChangeText={setBloodGroup}
            />
          </View>
          <View style={styles.inputContainer}>
            <Text style={[styles.label, styles.nameLabel]}>Age:</Text>


            <TextInput
              style={styles.input}
              value={age}
              onChangeText={setAge}
              keyboardType="numeric"
            />
          </View>
          <View style={styles.inputContainer}>
            <Text style={[styles.label, styles.nameLabel]}>Address1:</Text>


            <TextInput
              style={styles.input}
              value={Address1}
              onChangeText={setAddress1}
            />
          </View>
          <View style={styles.inputContainer}>
            <Text style={[styles.label, styles.nameLabel]}>Address2:</Text>
            <TextInput
              style={styles.input}
              value={Address2}
              onChangeText={setAddress2}
            />
          </View>
          <View style={styles.inputContainer}>
            <Text style={[styles.label, styles.nameLabel]}>SymptomId:</Text>

            <TextInput
              style={styles.input}
              value={SymptomId}
              onChangeText={setSymptomId}
            />
          </View>

          <View style={styles.btn}>
            <Button
              color="#264d73"
              title="Save"
              onPress={handleUpdatePatient}
            />
          </View>
        </View>
      </ScrollView>
    </GestureHandlerRootView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 50,
    backgroundColor: "#2a7fba", // Set background color here
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  formContainer: {
    width: "80%",
  },
  nameLabel: {
    fontSize: 15,
    color: "black" // Custom font size for Patient Name label
  },
  title: {
    fontSize: 30,
    marginBottom: 20,
    color: "white",
    textAlign: "center",
  },
  inputout: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  inputContainer: {
    marginBottom: 2,
    width: "100%",
  },

  labelText: {
    width: 120, // Set a fixed width for labels to align them
    textAlign: "right", // Align text to the right within the label container
    marginRight: 10, // Add some spacing between label and input
    marginBottom: 5,
    color: "white",
  },
  label: {
    width: "50%",
    marginRight: 10,
    color: "white",
  },

  input: {
    flex: 1,
    marginLeft: 10,
    borderWidth: 1,
    borderColor: "#ccc",
    paddingVertical: 8,
    paddingHorizontal: 10,
    backgroundColor: "white",
    borderRadius: 5,
    color: "#333",
    width: "100%", // Take up full width
    marginBottom: 10,
  },
  btn: {
    marginTop: 20,
    width: "50%",
  },
});

export default UpdatePatient;
